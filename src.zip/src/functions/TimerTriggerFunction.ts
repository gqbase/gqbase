import { app, InvocationContext, Timer } from "@azure/functions";
import * as df from "durable-functions";

interface ScheduleInput {
    timestamp: string;
    scheduleType: string;
}

export async function TimerTriggerFunction(myTimer: Timer, context: InvocationContext): Promise<void> {
    try {   
        context.log('Timer trigger fired at:', new Date().toISOString());
        const client = df.getClient(context);       
        const orchestratorId = 'SchedulerOrchestratorInstance';
        
        const timeStamp = new Date().toISOString();
        let status = null; 

        try {
            status = await client.getStatus(orchestratorId);
            context.log('Current orchestrator status:', status?.runtimeStatus);
        } catch (error) {
            // If the orchestrator doesn't exist, status will be null
            context.log('No existing orchestrator instance found');
        }
            
        if (!status || 
            status.runtimeStatus === 'Completed' || 
            status.runtimeStatus === 'Failed' || 
            status.runtimeStatus === 'Terminated') {
            
            // Clean up any existing instance
            if (status) {
                try {
                    await client.terminate(orchestratorId, "Cleaning up before restart");
                    context.log('Terminated existing orchestrator instance');
                } catch (error) {
                    context.log('Error terminating orchestrator:', error);
                }
            }

            // Start a new orchestration instance
            const instanceId = await client.startNew("ScheduleOrchestrator", {
                instanceId: orchestratorId,
                input: {
                    timestamp: timeStamp,
                    scheduleType: "timer"
                } as ScheduleInput
            });
            
            context.log(`Started new orchestration with ID = '${instanceId}'`);
        } else {
            context.log(`Orchestration '${orchestratorId}' is already running with status: ${status.runtimeStatus}`);
        }
        
    } catch (error) {
        context.error(`Error in timer trigger: ${error instanceof Error ? error.message : 'Unknown error'}`);
        throw error;
    }
}

app.timer('TimerTriggerFunction', {
    schedule: '*/5 * * * * *', // Runs every 5 seconds for testing, adjust as needed
    handler: TimerTriggerFunction,
    extraInputs: [df.input.durableClient()]
});
