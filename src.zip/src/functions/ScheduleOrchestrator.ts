import { app, HttpHandler, HttpRequest, HttpResponse, InvocationContext } from '@azure/functions';
import * as df from 'durable-functions';
import { ActivityHandler, OrchestrationContext, OrchestrationHandler } from 'durable-functions';
import { AgendaScheduler, mongoConnectionString } from '../agendaScheduler';

interface ScheduleInput {
    timestamp: string;
    scheduleType: string;
}

const activityName = 'ScheduleActivity';

const ScheduleOrchestrator: OrchestrationHandler = function* (context: OrchestrationContext) {
    try {
        context.log('Orchestrator started');
        const input = context.df.getInput<ScheduleInput>();
        
        while (true) {
            try {
                context.log('Calling activity');
                yield context.df.callActivity(activityName, { 
                    timestamp: context.df.currentUtcDateTime.toISOString(),
                    scheduleType: input?.scheduleType || 'timer'
                });
                
                // Schedule next run in 1 minute
                const nextRun = new Date(context.df.currentUtcDateTime);
                nextRun.setMinutes(nextRun.getMinutes() + 1);
                context.log('Scheduling next run at:', nextRun);
                yield context.df.createTimer(nextRun);
            } catch (error) {
                context.log(`Error in orchestration loop: ${error instanceof Error ? error.message : 'Unknown error'}`);
                // Wait for 30 seconds before retrying on error
                yield context.df.createTimer(new Date(Date.now() + 30000));
            }
        }
    } catch (error) {
        context.log(`Fatal error in orchestrator: ${error instanceof Error ? error.message : 'Unknown error'}`);
        throw error;
    }
};

const ScheduleActivity: ActivityHandler = async (input: { timestamp: string; scheduleType: string }): Promise<string> => {
    let scheduler: AgendaScheduler | null = null;
    try {
        scheduler = new AgendaScheduler(mongoConnectionString);
        await scheduler.start();

        // Define the job
        scheduler.defineJob('logTimestamp', async (job) => {
            console.log(`Task executed at: ${input.timestamp}`);
        });

        // Schedule the job
        await scheduler.scheduleJob('logTimestamp', '1 minute');
        
        return `Scheduled task executed at ${input.timestamp}`;
    } catch (error) {
        console.error('Error in schedule activity:', error);
        throw error;
    } finally {
        if (scheduler) {
            try {
                await scheduler.stop();
            } catch (error) {
                console.error('Error stopping scheduler:', error);
            }
        }
    }
};

// Register the orchestrator and activity
df.app.orchestration('ScheduleOrchestrator', ScheduleOrchestrator);
df.app.activity(activityName, { handler: ScheduleActivity }); 