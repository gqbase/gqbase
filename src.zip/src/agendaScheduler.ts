import Agenda from 'agenda';

export class AgendaScheduler {
  private agenda: Agenda;

  constructor(mongoConnectionString: string) {
    console.log('Agenda Constructor');
    this.agenda = new Agenda({
      db: { address: mongoConnectionString, collection: 'agendaJobs' },
      processEvery: '1 minute'
    });
  }

  async start() {
    console.log('Agenda start');
    await this.agenda.start();
    console.log('Agenda scheduler started');
  }

  async defineJob(jobName: string, fn: (job: any) => Promise<void>) {
    console.log('Agenda defineJob');
    this.agenda.define(jobName, async (job) => {
      try {
        await fn(job);
      } catch (error) {
        console.error(`Error in job ${jobName}:`, error);
      }
    });
  }

  async scheduleJob(jobName: string, interval: string) {
    console.log('Agenda scheduleJob');
    await this.agenda.every(interval, jobName);
    console.log(`Job ${jobName} scheduled to run every ${interval}`);
  }

  async stop() {
    console.log('Agenda stop');
    await this.agenda.stop();
    console.log('Agenda scheduler stopped');
  }
}

export const mongoConnectionString = process.env.MONGODB_URI as string;
 

